﻿namespace MVC_Project.DTO
{
    public class OTPReqDto
    {
        public string flag { get; set; }
        public int accId { get; set; }
        public string mobileNo { get; set; }
    }
}
