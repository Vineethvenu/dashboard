﻿namespace MVC_Project.DTO
{
    public class OTPResDto
    {
        public string status { get; set; }
        public int message { get; set; }
    }
}
