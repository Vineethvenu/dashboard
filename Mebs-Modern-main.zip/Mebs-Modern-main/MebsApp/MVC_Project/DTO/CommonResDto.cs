﻿namespace MVC_Project.DTO
{
    public class CommonResDto
    {
        public string Common_Result { get; set; }
    }
}
