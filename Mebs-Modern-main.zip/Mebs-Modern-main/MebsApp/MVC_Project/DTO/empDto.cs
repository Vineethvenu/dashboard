﻿namespace MVC_Project.DTO
{
    public class empDto
    {
        public string EMP_NAME { get; set; }
        public string BRANCH_NAME { get; set; }
    }
}
