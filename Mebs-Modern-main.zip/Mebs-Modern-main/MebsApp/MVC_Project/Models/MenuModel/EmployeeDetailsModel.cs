﻿namespace MVC_Project.Models.MenuModel
{
    public class EmployeeDetailsModel
    {
        public string EmpCode { get; set; } = string.Empty;
        public string EMP_NAME { get; set; } = string.Empty;
        public string Designation { get; set; } = string.Empty;

        public string BRANCH_NAME { get;set; } = string.Empty;
    }
}
