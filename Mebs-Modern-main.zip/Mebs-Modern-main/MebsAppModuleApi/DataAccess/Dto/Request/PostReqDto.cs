﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Dto.Request
{
    public class PostReqDto
    {
        public string p_pagevalue { get; set; } = string.Empty;
        public string p_paravalue { get; set; } = string.Empty;
        public string p_flag { get; set; } = string.Empty;

    }
}
