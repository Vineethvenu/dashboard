﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Dto.Response
{
    public class PostResDto
    {
        public dynamic ResponseData { get; set; } = 0;
    }
}
