﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Entities
{
    public class ErrorResponse
    {
        public List<string> errorMessage { get; set; }

    }
}
